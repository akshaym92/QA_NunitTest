﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace CircleModify
{
    [TestFixture]
    public class CircleTest
    {
        [Test]
        public void Constructortest()
        {
            
            Circle circleTestObj1 = new Circle();
            circleTestObj1.radiusOfCircle = -4;
            Assert.AreEqual(false, circleTestObj1.Isture);

        }
        [Test]
        public void AddToRadius_withPositiveradius()

        {
            Circle Positiveradius = new Circle();
            Positiveradius.radiusOfCircle = 10;
            Positiveradius.AddToRadius(6);
            Assert.AreEqual(16, Positiveradius.radiusOfCircle);
        }
        [Test]
        public void AddToRadius_withnegetiveradius()
        {
            Circle negativeradius = new Circle();
            negativeradius.radiusOfCircle = 2;
            negativeradius.AddToRadius(-4);
            Assert.AreEqual(-2, negativeradius.radiusOfCircle);

        }
        [Test]
        public void SubtractFromRadius_withPositiveradius()
        {

            Circle Positiverad = new Circle();
            Positiverad.radiusOfCircle = 10;
            Positiverad.SubtractFromRadius(6);
            Assert.AreEqual(4, Positiverad.radiusOfCircle);


        }
        [Test]
        public void SubtractFromRadius_withnegetiveradius()
        {
            Circle negativerad = new Circle();
            negativerad.radiusOfCircle = 2;
            negativerad.SubtractFromRadius(6);
            Assert.AreEqual(-4, negativerad.radiusOfCircle);
        }
        [Test]
       
        public void GetCircumference()
        {
            Circle circletestobj1 = new Circle();
            circletestobj1.radiusOfCircle = 3;
            circletestobj1.GetCircumference();
            Assert.AreEqual(18.84,circletestobj1.GetCircumference());
        }
       
        [Test]
        public void GetAreaTest()
        {
            Circle circletestobj1 = new Circle();
            circletestobj1.radiusOfCircle = 2;
            circletestobj1.GetArea();
            Assert.AreEqual(12.56,circletestobj1.GetArea());
        }

    
}
}
       

    


