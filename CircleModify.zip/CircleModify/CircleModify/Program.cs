﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleModify
{
    public class Program
    {

        static void Main(string[] args)
        {
            int choice = 0;
            double radius = 0;
            bool check=true;
            

            Console.WriteLine("Enter the radius");
            radius = Convert.ToDouble(Console.ReadLine());

            //circleObj1.radiusOfCircle = Convert.ToDouble(Console.ReadLine());

            if (radius < 0)
            {
                check = false;
            }
            else
            {
                check = true;
            }

            Circle circleObj1 = new Circle(radius, check);
            do
            {
                Console.WriteLine("Select From the menu");
                Console.WriteLine("1.Add radius");
                Console.WriteLine("2.subtract radius");
                Console.WriteLine("3.Find Circumference");
                Console.WriteLine("4.Find Area");
                Console.WriteLine("5.Exit");



                try
                {
                    Console.Write("Please Enter your choice(1/2/3/4/5) : ");
                    choice = Convert.ToInt16(Console.ReadLine());

                }
                catch (Exception e)
                {
                    Console.WriteLine("Your choice is invalid...please enter a valid chocie(1/2/3/4/5)");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadLine();

                }
                finally
                {
                    Console.Clear();
                }

                switch (choice)
                {
                    case 1:

                        Console.WriteLine("Enter the value to Add");
                        double numberToADD = Convert.ToInt32(Console.ReadLine());
                        circleObj1.AddToRadius(numberToADD);
                        break;
                    case 2:
                        Console.WriteLine("Enter the value to Subtract");
                        double numberToSubtract = Convert.ToInt32(Console.ReadLine());
                        circleObj1.SubtractFromRadius(numberToSubtract);
                        break;
                    case 3:
                        double circumference = circleObj1.GetCircumference();
                        Console.WriteLine("Circumference of the cirle is:" + circumference);
                        break;
                    case 4:
                        double area = circleObj1.GetArea();
                        Console.WriteLine("area of the cirle is:" + area);

                        break;

                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            } while (choice != 5);
            } 

        }

    }











