﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleModify
{
    public class Circle
    {
        public const double pie= 3.14;
        public double radiusOfCircle { get; set; }
        public bool Isture;
        //default construtor
        public Circle()
        {
        }
        public Circle(double radius,bool istrue)
        {
            this.radiusOfCircle = radius;
            Console.WriteLine("Radius=" +this.radiusOfCircle);
            this.Isture = istrue;

        }
        public  void AddToRadius(double num)
        {
            this.radiusOfCircle = this.radiusOfCircle + num;
            Console.WriteLine("New radius is {0}", radiusOfCircle);
            Console.ReadLine();
        }
        public void SubtractFromRadius(double num)
        {
            this.radiusOfCircle = this.radiusOfCircle - (num);
            Console.WriteLine("New radius is {0}", radiusOfCircle);
            Console.ReadLine();

        }
        public double GetCircumference()

        {
            double circumference = 2 * pie * radiusOfCircle;
            return circumference;
          

        }
        public double GetArea()
        {
            double area = pie * radiusOfCircle * radiusOfCircle;
            return area;
           

        }
    }
}



